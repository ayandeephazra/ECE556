Team - AMD Ryzen 10
Members -
    1) Surya Santhan Thenarasu
    2) Ayan Deep Hazra
Share of Workload - 
    1) int readBenchmark(const char *fileName, routingInst *rst) -> Ayan
    2) int solveRouting(routingInst *rst) -> Surya
    3) int writeOutput(const char *outRouteFile, routingInst *rst) -> Ayan
    4) int release(routingInst *rst) -> Surya/Ayan